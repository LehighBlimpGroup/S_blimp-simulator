# sensfusion
Arduino based sensor fusion for 10x gyro, accelerometer, magnetometer, and barometer
