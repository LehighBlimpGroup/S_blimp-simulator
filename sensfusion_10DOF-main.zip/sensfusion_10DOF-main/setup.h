
void escarm(Servo& thrust1, Servo& thrust2)
